package com.firstProject.firstProject.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.firstProject.firstProject.model.Customer;
import com.firstProject.firstProject.model.CustomerStatus;
import com.firstProject.firstProject.repository.CustomerRepositoryLess61;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerServiceLess63 {
    @Autowired
    CustomerRepositoryLess61 customerRrpository;
    @Autowired
    ObjectMapper objectMapper;//less63 משמש להפוך אובייקט למחרוזת ולהפך


    @Override
    public Long createCustomer(Customer customer) throws Exception {//יצירה עד עשר וי איי פי
        //הפיכה מאובייקט לסטרינג גייסון
        String customerAsString = objectMapper.writeValueAsString(customer);
        System.out.println("customerAsString: " + customerAsString);
        Customer customerFromString = objectMapper.readValue(customerAsString, Customer.class);
        System.out.println("customerFromString: " + customerFromString);
        if (customer.getStatus() == CustomerStatus.VIP) {
            List<Customer> vipCustomers = customerRrpository.getAllCustomersByStatus(customer.getStatus());//או לבדוק == CustomerStatus.VIP
            if (vipCustomers.size() < 10)
                return customerRrpository.createCustomer(customer);
            else
                throw new Exception("cant create new customer with VIP status, out if limit");
        } else
            return customerRrpository.createCustomer(customer);

    }

    @Override
    public void updateCustomerById(Long customerId, Customer customer) throws Exception {
        if (customer.getStatus() == CustomerStatus.VIP && customerRrpository.getCustomerById(customerId).getStatus() == CustomerStatus.REGULAR) {
            List<Customer> vipCustomers = customerRrpository.getAllCustomersByStatus(customer.getStatus());//או לבדוק == CustomerStatus.VIP
            if (vipCustomers.size() < 10)
                customerRrpository.updateCustomerById(customerId, customer);
            else
                throw new Exception("cant update customer to VIP status, out if limit");
        } else
            customerRrpository.updateCustomerById(customerId, customer);
    }

    @Override
    public void deleteCustomer(Long id) throws Exception {
        if (customerRrpository.getCustomerById(id) != null)
            customerRrpository.deleteCustomer(id);
        else
            throw new Exception("customer is not exists");
    }

    @Override
    public Customer getCustomerById(Long id) {
        return customerRrpository.getCustomerById(id);
    }

    @Override
    public List<Customer> getCustomersByFirstName(String firstName) {
        return customerRrpository.getCustomersByFirstName(firstName);
    }

    @Override
    public List<Customer> getAllCustomers() {
        return customerRrpository.getAllCustomers();
    }

    @Override
    public List<Long> getCustomersIdsByFirstName(String firstName) {
        return customerRrpository.getCustomersIdsByFirstName(firstName);
    }
}
